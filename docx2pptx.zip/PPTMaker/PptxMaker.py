import PPTMaker.source.pclasstoppt as maker


class PptxMaker:
    def make_ppt(self, pclass):
        maker.makeppt(pclass)
